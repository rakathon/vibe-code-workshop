## [1.0.2](https://github.com/rewards-guilds/rr-lunchnlearn-web/compare/v1.0.1...v1.0.2) (2026-04-29)

## [1.0.1](https://github.com/rewards-guilds/rr-lunchnlearn-web/compare/v1.0.0...v1.0.1) (2026-04-29)

## 1.0.0 (2026-04-29)

### Features

* init commit 🪺 ([14e13db](https://github.com/rewards-guilds/rr-lunchnlearn-web/commit/14e13dbee73477858518005daaa0806c46de00fa))

# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [2.13.4](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.13.3...v2.13.4) (2025-04-30)

**Note:** Version bump only for package rr-next-template





## [2.13.3](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.13.2...v2.13.3) (2025-04-24)

**Note:** Version bump only for package rr-next-template





## [2.13.2](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.13.1...v2.13.2) (2025-04-08)


### Features

* RCS-6999 - Update template's CD workflow to output container logs ([#1534](https://github.com/rewards-foundation/rakuten-rewards-next/issues/1534)) ([195f878](https://github.com/rewards-foundation/rakuten-rewards-next/commit/195f878342b00f6747cd106bd0aac085d324a0af))


### Bug Fixes

* RCS-7004 - Remove IPv4 host setting from deploy.Dockerfile ([#1533](https://github.com/rewards-foundation/rakuten-rewards-next/issues/1533)) ([1151332](https://github.com/rewards-foundation/rakuten-rewards-next/commit/115133244df46ad214c53e30c9c02c7390e2f61c))



## [2.13.1](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.13.0...v2.13.1) (2025-03-31)


### Bug Fixes

* RCS-6776 - Opt out of SRI support by default, fail gracefully on content syncing ([#1531](https://github.com/rewards-foundation/rakuten-rewards-next/issues/1531)) ([7876db0](https://github.com/rewards-foundation/rakuten-rewards-next/commit/7876db066439ae09d84e6b1a35134b64d816e118))



## [2.13.0](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.12.1...v2.13.0) (2025-03-26)


### Features

* RCS-6726 - Upload client source map files to DataDog ([#1511](https://github.com/rewards-foundation/rakuten-rewards-next/issues/1511)) ([8b79908](https://github.com/rewards-foundation/rakuten-rewards-next/commit/8b79908f5b5d57ace28ae48e10fcc9a1702fe952))



## [2.12.1](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.12.0...v2.12.1) (2025-03-06)

**Note:** Version bump only for package rr-next-template





## [2.12.0](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.11.0...v2.12.0) (2025-02-19)

**Note:** Version bump only for package rr-next-template





## [2.11.0](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.10.0...v2.11.0) (2025-02-13)


### Features

* REC-56 - Remove unused Jenkins files from template ([#1408](https://github.com/rewards-foundation/rakuten-rewards-next/issues/1408)) ([f820d84](https://github.com/rewards-foundation/rakuten-rewards-next/commit/f820d84383679865722eff6ea15517382e9e7e18))


### Bug Fixes

* REC-81 - Update `.gitignore` to include Yarn files for the template ([#1434](https://github.com/rewards-foundation/rakuten-rewards-next/issues/1434)) ([9e6e0fe](https://github.com/rewards-foundation/rakuten-rewards-next/commit/9e6e0fe042eabd3c6d19c8bbfe66fc04e413681e))



## [2.10.0](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.9.1...v2.10.0) (2024-10-15)


### Features

* REC-52 - Add Jest Reporters and remove Jest Coverage defaults ([#1401](https://github.com/rewards-foundation/rakuten-rewards-next/issues/1401)) ([71e59e0](https://github.com/rewards-foundation/rakuten-rewards-next/commit/71e59e0bc9a6779ef07a825c61cfd30f258468e4))


### Bug Fixes

* EBTOOL-11249 - Update scaffold test script to use rr-next bin ([a794fee](https://github.com/rewards-foundation/rakuten-rewards-next/commit/a794fee173865372b91d342e32c70f5d15723b67))



## [2.9.1](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.9.0...v2.9.1) (2024-10-09)


### Bug Fixes

* EBTOOL-11249 - Disable Yarn telemetry collection ([fe91161](https://github.com/rewards-foundation/rakuten-rewards-next/commit/fe9116160a273edc00b33008ebd6719c067458fd))



## [2.9.0](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.8.1...v2.9.0) (2024-09-16)


### Features

* EBTOOL-11249 - Migrate to Yarn v4 & Node v20 ([#1323](https://github.com/rewards-foundation/rakuten-rewards-next/issues/1323)) ([708ce66](https://github.com/rewards-foundation/rakuten-rewards-next/commit/708ce66ce4c8f2bd5644526cb9f968b3bfd7b3d6))



## [2.8.1](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.8.0...v2.8.1) (2024-07-29)

**Note:** Version bump only for package rr-next-template





## [2.8.0](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.7.2...v2.8.0) (2024-07-25)


### Features

* EBTOOL-11245 - Expose bins, add script commands to handle transitive dependencies ([#1324](https://github.com/rewards-foundation/rakuten-rewards-next/issues/1324)) ([2dfa3ef](https://github.com/rewards-foundation/rakuten-rewards-next/commit/2dfa3efe3f8df22df6cc75496cc97406ca443ee2))
* RCS-4632 - Add npm and yarn rc files + rr-registry directive for scoped rr dependencies ([#1308](https://github.com/rewards-foundation/rakuten-rewards-next/issues/1308)) ([e86e152](https://github.com/rewards-foundation/rakuten-rewards-next/commit/e86e15299039e43248df0a0e37a7e3e3d55c78e9))



## [2.7.2](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.7.1...v2.7.2) (2024-07-16)

**Note:** Version bump only for package rr-next-template





## [2.7.1](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.7.0...v2.7.1) (2024-06-10)

**Note:** Version bump only for package rr-next-template





## [2.7.0](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.6.1...v2.7.0) (2024-06-06)


### Features

* PDO-3260 - Update template to follow `v2.3.8` GHA standard ([#1228](https://github.com/rewards-foundation/rakuten-rewards-next/issues/1228)) ([8391a1f](https://github.com/rewards-foundation/rakuten-rewards-next/commit/8391a1fabd29480e40f2564e8ecef79f0342bb04))


### Bug Fixes

* PDO-4419 - Update Datadog Nginx annotations to match V2 ([#1158](https://github.com/rewards-foundation/rakuten-rewards-next/issues/1158)) ([3af67c4](https://github.com/rewards-foundation/rakuten-rewards-next/commit/3af67c43835d5b817643b64a7b08db4e2eb53a6c))



## [2.6.1](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.6.0...v2.6.1) (2024-03-13)

**Note:** Version bump only for package rr-next-template





## [2.6.0](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.5.1...v2.6.0) (2024-03-09)

**Note:** Version bump only for package rr-next-template





## [2.5.1](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.5.0...v2.5.1) (2024-02-28)

**Note:** Version bump only for package rr-next-template





## [2.5.0](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.4.0...v2.5.0) (2024-02-28)

**Note:** Version bump only for package rr-next-template





## [2.4.0](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.3.1...v2.4.0) (2024-02-05)

**Note:** Version bump only for package rr-next-template





## [2.3.1](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.3.0...v2.3.1) (2023-10-23)

**Note:** Version bump only for package rr-next-template





## [2.3.0](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.2.1...v2.3.0) (2023-10-13)

**Note:** Version bump only for package rr-next-template





## [2.2.1](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.2.0...v2.2.1) (2023-10-06)


### Bug Fixes

* **testing:** RCS-4733 - Update Jest file mocks for tests ([#1152](https://github.com/rewards-foundation/rakuten-rewards-next/issues/1152)) ([8ea76c4](https://github.com/rewards-foundation/rakuten-rewards-next/commit/8ea76c4d6db6bb21e28cf154318e0d4fbd7ba56a))



## [2.2.0](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.1.2...v2.2.0) (2023-10-02)

**Note:** Version bump only for package rr-next-template





## [2.1.2](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.1.1...v2.1.2) (2023-08-16)

**Note:** Version bump only for package rr-next-template





## [2.1.1](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.1.0...v2.1.1) (2023-08-11)

**Note:** Version bump only for package rr-next-template





## [2.1.0](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.0.2...v2.1.0) (2023-07-26)


### Bug Fixes

* Remove duplicate imageTag entry in scaffold template deploy schema ([4b18c7b](https://github.com/rewards-foundation/rakuten-rewards-next/commit/4b18c7bb298a252ebf821466c0dc1f921adfbcc7))



## [2.0.2](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.0.1...v2.0.2) (2023-06-27)


### Features

* PDO-3039 - Update template GHA workflows to GHA v2.x ([#1056](https://github.com/rewards-foundation/rakuten-rewards-next/issues/1056)) ([dd389a7](https://github.com/rewards-foundation/rakuten-rewards-next/commit/dd389a71d39cc10c2ae29ad3553a507188223144))


### Bug Fixes

* RCS-3548 - Use env specific staticHost domains for resolving UIKit fontsets ([#1041](https://github.com/rewards-foundation/rakuten-rewards-next/issues/1041)) ([0885bd9](https://github.com/rewards-foundation/rakuten-rewards-next/commit/0885bd9b63a0f9560a0eb408183750ce086ce11f))



## [2.0.1](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v2.0.0...v2.0.1) (2023-06-02)

**Note:** Version bump only for package rr-next-template





## [2.0.0](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v1.34.2...v2.0.0) (2023-06-01)


### ⚠ BREAKING CHANGES

* DSC-3868 - Update NextJS to v13 & React to v18 (#991)

### Features

* DSC-3868 - Update NextJS to v13 & React to v18 ([#991](https://github.com/rewards-foundation/rakuten-rewards-next/issues/991)) ([673a200](https://github.com/rewards-foundation/rakuten-rewards-next/commit/673a200ab95c5096a741344e9879388218dedaab))



## [1.34.2](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v1.34.1...v1.34.2) (2023-05-02)

**Note:** Version bump only for package rr-next-template





## [1.34.1](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v1.34.0...v1.34.1) (2023-04-11)


### Continuous Integration

* RCS-4198 - Fix PR Title check ([#1015](https://github.com/rewards-foundation/rakuten-rewards-next/issues/1015)) ([d45f511](https://github.com/rewards-foundation/rakuten-rewards-next/commit/d45f5110e6d3d51636e3872ff935a1e7519f017d))



## [1.34.0](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v1.33.0...v1.34.0) (2023-04-04)


### Features

* DSC-3841 - Set up local development environment for testing changes ([#979](https://github.com/rewards-foundation/rakuten-rewards-next/issues/979)) ([c2a5919](https://github.com/rewards-foundation/rakuten-rewards-next/commit/c2a59191aff995f52c064153814eee7d7736e46e))
* DSC-3864 - Upgrade to Node v18 ([#981](https://github.com/rewards-foundation/rakuten-rewards-next/issues/981)) ([b0643ae](https://github.com/rewards-foundation/rakuten-rewards-next/commit/b0643ae4740e850bf70f1bb0453c38395ee710e0))


### Bug Fixes

* DSC-3841 - Ensure that prepublish script exits upon failure ([#990](https://github.com/rewards-foundation/rakuten-rewards-next/issues/990)) ([9a117c0](https://github.com/rewards-foundation/rakuten-rewards-next/commit/9a117c09fb90ba55aeaef4ab4f50f068eb1d0c56))


### Continuous Integration

* Add permissions spec to PR check GHA workflows ([#1011](https://github.com/rewards-foundation/rakuten-rewards-next/issues/1011)) ([f25f08b](https://github.com/rewards-foundation/rakuten-rewards-next/commit/f25f08b0915a4ab276127b0c8c7e4509a90a8a2d))



## [1.34.0](https://github.com/rewards-foundation/rakuten-rewards-next/compare/v1.33.0...v1.34.0) (2023-04-04)


### Features

* DSC-3841 - Set up local development environment for testing changes ([#979](https://github.com/rewards-foundation/rakuten-rewards-next/issues/979)) ([c2a5919](https://github.com/rewards-foundation/rakuten-rewards-next/commit/c2a59191aff995f52c064153814eee7d7736e46e))
* DSC-3864 - Upgrade to Node v18 ([#981](https://github.com/rewards-foundation/rakuten-rewards-next/issues/981)) ([b0643ae](https://github.com/rewards-foundation/rakuten-rewards-next/commit/b0643ae4740e850bf70f1bb0453c38395ee710e0))


### Bug Fixes

* DSC-3841 - Ensure that prepublish script exits upon failure ([#990](https://github.com/rewards-foundation/rakuten-rewards-next/issues/990)) ([9a117c0](https://github.com/rewards-foundation/rakuten-rewards-next/commit/9a117c09fb90ba55aeaef4ab4f50f068eb1d0c56))
* DSC-3855 - Remove the `next-compose-plugins` to remove some warnings ([#977](https://github.com/rewards-foundation/rakuten-rewards-next/issues/977)) ([0e67cb1](https://github.com/rewards-foundation/rakuten-rewards-next/commit/0e67cb17a12dc24528e3deefc6f36edcef9234e5))


### Reverts

* DSC-3855 - Remove the `next-compose-plugins` to remove some warnings ([#999](https://github.com/rewards-foundation/rakuten-rewards-next/issues/999)) ([4f18341](https://github.com/rewards-foundation/rakuten-rewards-next/commit/4f183411ad1f2d50fbd63f34fe92340493372a86))
