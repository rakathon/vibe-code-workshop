#!/bin/bash
rm -rf ${CI_BUILD_ARTIFACT_DIR}
mkdir ${CI_BUILD_ARTIFACT_DIR}

#lint
yarn eslint . -f checkstyle -o ${CI_BUILD_ARTIFACT_DIR}/eslint.xml || true
yarn --silent stylelint './**/*.js' --custom-formatter node_modules/stylelint-checkstyle-formatter > ${CI_BUILD_ARTIFACT_DIR}/stylelint.xml || true

#test
export JEST_JUNIT_OUTPUT_DIR=${CI_BUILD_ARTIFACT_DIR}
yarn test --ci --reporters=default --reporters=jest-junit || true

#build and pack
yarn build
yarn pack
mv *.tgz ${CI_BUILD_ARTIFACT_DIR}