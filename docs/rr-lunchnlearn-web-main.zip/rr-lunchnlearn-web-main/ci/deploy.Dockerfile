# syntax = docker/dockerfile:1.0-experimental
# placeholder for dependabot to check new version of alpine
# NOTICE: please manually update the alpine version in node image tag below when dependabot detects new version
FROM public.ecr.aws/docker/library/alpine:3.22.1 AS detector

# install npm packages
FROM public.ecr.aws/docker/library/node:20.19.2-alpine3.22 AS installer
RUN apk add --no-cache git bash
RUN mkdir -p /app
RUN mkdir -p /app/config && chown node:node /app/config
ARG GHPAT_PATH=/run/secrets/ghpat
WORKDIR /app
COPY ./.yarnrc.yml .
COPY package.json .
COPY yarn.lock .
RUN corepack enable
RUN --mount=type=secret,id=ghpat \
  echo -e "machine github.com\nlogin rr-devops-bot\npassword $(cat $GHPAT_PATH)" > ~/.netrc
RUN YARN_ENABLE_SCRIPTS=false HUSKY=0 yarn workspaces focus --all --production && \
  rm ~/.netrc && \
  rm -rf .next/cache

# start app
FROM installer
WORKDIR /app
ADD ci_artifacts/rr-lunchnlearn-web.tgz ./
RUN cp -r package/. . && rm -rf package
EXPOSE 3000

RUN echo -e "\
  # use the configs from configmap
  [[ -d /opt/configs/ ]] && cp --verbose /opt/configs/* /app/config/ \n\
  yarn start \
  " > /bootstrap && chmod +x /bootstrap

USER node
CMD /bootstrap
