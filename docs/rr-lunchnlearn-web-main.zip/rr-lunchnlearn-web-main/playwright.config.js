import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests',
  retries: 2,
  testMatch: '**/*.spec.ts',
  reporter: [
    ['list'], // You can keep the default 'list' reporter for console output
    ['junit', { outputFile: 'test-results/junit.xml' }], // Add this line for JUnit
  ],
  use: {
    // headless: false,
    // Base URL to use in actions like `await page.goto('/')`.
    baseURL: process.env?.BASE_URL || 'https://qa1-www.rakuten.com/',

    // Collect trace when retrying the failed test.
    trace: 'on-first-retry',
  },

  // Run all tests in parallel.
  fullyParallel: true,
  projects: [
    {
      name: 'chrome',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
});
