import { render } from '@rakuten-rewards/next-dev-tools/tests';
import Home from '../pages/index';

describe('Home', () => {
  it('renders "Welcome to rr-lunchnlearn-web"', () => {
    const { container, getByText } = render(<Home />);

    expect(getByText(/rr-lunchnlearn-web/));

    expect(container).toMatchSnapshot();
  });
});
