import { keyframes } from '@emotion/react';
import {
  Box,
  Flex,
  Button,
  Paragraph,
  Link,
  Heading,
  Image,
} from '@rakuten-rewards/uikit';
import radiantLogo from '~/assets/radiant.svg';

const SpinKeyframes = keyframes`
  0% {
    transform: perspective(360px) rotateX(0deg) rotateY(0deg);
  } 100% {
    transform: perspective(360px) rotateX(0deg) rotateY(360deg);
  }
`;

const projectName = 'rr-lunchnlearn-web';

function Home() {
  return (
    <Flex
      as="header"
      backgroundColor="palette.almostBlack"
      minH="100vh"
      flexDirection="column"
      align="center"
      justify="center"
      color="text.inverse"
      textAlign="center"
    >
      <Flex
        as={Link}
        href="https://rakuten-rewards-uikit-qa.clientserv-np.rr-it.com/"
        target="_blank"
        justify="center"
        align="center"
        title="Check out the Radiant Web UIKit here!"
        color="text.inverse"
        mb="grande"
      >
        <Image
          src={radiantLogo}
          alt="Check out the Radiant Web UIKit here!"
          w={150}
          animation={`${SpinKeyframes} infinite 5s linear`}
        />
        <Heading
          as="h1"
          color="palette.purple_200"
        >
          ADIANT
        </Heading>
      </Flex>
      <Heading as="h2" mb="venti">
        Welcome to&nbsp;
        <Box
          fontWeight="600"
          as="code"
          color="palette.purple_100"
        >
          {projectName}
        </Box>
      </Heading>
      <Box as="article">
        <Paragraph mb={20} textStyle="descriptorMedium">
          To get started, edit <code>src/pages/index.tsx</code> or <code>src/pages/_app..tsx</code> and save to reload.
        </Paragraph>
        <Button
          variant="secondary"
          as={Link}
          href="https://rakutenrewards.atlassian.net/wiki/spaces/GUILDS/pages/19586353196/Radiant+React+Web+Development+Playbook+and+Guide"
          target="_blank"
        >
          Let&apos;s Go!
        </Button>
      </Box>
    </Flex>
  );
}

export default Home;
