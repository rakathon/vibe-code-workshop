export { default } from '@rakuten-rewards/next/document';
