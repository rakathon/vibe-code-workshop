import React from 'react';
import { createApp } from '@rakuten-rewards/next/app';
import HeadMeta from '../components/HeadMeta';

const Decorator: React.FC = ({ children }) => (
  <>
    <HeadMeta />
    {children}
  </>
);

const App = createApp({ Decorator });

export default App;
