// Placeholder for 500 error page to get around the build error
// for real project, may consider to be use the component from AppShell
// https://github.com/rewards-foundation/rakuten-rewards-appshell/blob/main/src/pages/500.tsx
export default function SystemError() {
  return 'Unknown Error';
}
