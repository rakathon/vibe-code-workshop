import Head from 'next/head';
import { useRouter } from 'next/router';

// Example of using the app state to access generic application level information
import { useApp } from '@rakuten-rewards/next/contexts';

/**
 * NOTE: Currently using a strategy of webapp hostname introspection to set the canonical url. Current thinking is
 * a webapp will control it's own route specification, with content being rendered for a route that would be considered
 * the true route that should be registered as a canonical url. Webapps should also be capable of issuing redirects
 * as necessary.
 *
 * If this strategy changes, we can update/refactor this part to reflect that change.
 */
function getCanonicalUrl(hostname: string, pathname: string): string {
  const normalizedPathname = pathname.replace(/^\/|\/$/g, '');

  return `https://${hostname}/${normalizedPathname}`;
}

export default function HeadMeta() {
  const { hostname } = useApp();
  const { pathname } = useRouter();

  const canonicalUrl = getCanonicalUrl(hostname, pathname);

  return (
    <Head>
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <link
        rel="icon"
        type="image/png"
        href="https://static.ebates.com/static/images/favicons-r/favicon-32x32.png"
        sizes="32x32"
      />
      <link rel="canonical" href={canonicalUrl} />
    </Head>
  );
}
