/* eslint-disable-next-line import/no-extraneous-dependencies */
const jestConfig = require('@rakuten-rewards/next-dev-tools/jest.config');

jestConfig.testPathIgnorePatterns = [
  ...(jestConfig.testPathIgnorePatterns || []),
  '<rootDir>/tests/integration/',
];

module.exports = jestConfig;
