const config = require('@rakuten-rewards/next/next.config');

module.exports = config;

// If you need to customize your projects Next or Webpack configurations, remove the above and uncomment the below
/*
const baseRRNextConfigComposer = require('@rakuten-rewards/next/next.config');

module.exports = (phase, { defaultConfig }) => {
  // Compute RRNext default Next config
  const baseRRNextConfig = baseRRNextConfigComposer(phase, { defaultConfig });
  const baseRRNextWebpackConfigComposer = baseRRNextConfig.webpack;

  // Specify your custom Webpack specific additions/overrides per
  // https://nextjs.org/docs/api-reference/next.config.js/custom-webpack-config here 👇
  const customWebpackConfigComposer = (config, options) => {
    // Compute RRNext default Webpack config
    const baseRRNextWebpackConfig = baseRRNextWebpackConfigComposer(config, options);

    return {
      ...baseRRNextWebpackConfig,
      // Start your custom Webpack configs here
    };
  };

  // Specify your custom NextJS configs per https://nextjs.org/docs/api-reference/next.config.js/introduction here 👇
  return {
    ...baseRRNextConfig,
    webpack: customWebpackConfigComposer,
    // Start your custom NextJS configs here
  };
};
*/
