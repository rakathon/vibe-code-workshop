/// <reference types="@rakuten-rewards/next/types/additional" />
