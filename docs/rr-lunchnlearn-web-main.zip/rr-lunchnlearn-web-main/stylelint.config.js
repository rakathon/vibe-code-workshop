module.exports = {
  extends: [
    '@rakuten-rewards/next-dev-tools/stylelint.config.js',
  ],
};
