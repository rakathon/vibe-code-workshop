import { test, expect } from '@playwright/test';

test.setTimeout(120_000);

test('Basic tests', async ({ page }) => {
  await page.goto('/');
  const title = await page.title();
  expect(title).toContain('Rakuten');
});
