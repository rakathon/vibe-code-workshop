// NOTE: when you need to enable/disable rules, or set as warnings, uncomment and utilize the
// constants below.
// const { OFF, WARNING, ERROR } = require('eslint-config-ebates/constants');

module.exports = {
  root: true,
  extends: [
    require.resolve('@rakuten-rewards/next-dev-tools/eslintrc.js'),
  ],
  rules: {
    'import/no-extraneous-dependencies': [
      'error',
      {
        devDependencies: [
          '**/*.{spec,test}.{js,jsx,ts,tsx}',
          'babel.config.js',
          '**/playwright.config.js',
          '**/tests/**',
        ],
      },
    ],
  },
};
