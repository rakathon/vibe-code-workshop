// https://github.com/yarnpkg/yarn/issues/761
// https://github.com/yarnpkg/yarn/issues/3630
const fs = require('fs');

const packageJson = JSON.parse(fs.readFileSync('package.json'));

delete packageJson.devDependencies;

fs.writeFileSync('package.json', JSON.stringify(packageJson, null, 2));
