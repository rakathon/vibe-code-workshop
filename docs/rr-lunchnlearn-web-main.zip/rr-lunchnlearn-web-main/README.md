[![License](https://img.shields.io/badge/GHA-v3.0-green)](https://rakutenrewards.atlassian.net/wiki/spaces/PDO/pages/41726411030/GHA+Releases)
[![License](https://img.shields.io/badge/Type-application-blue)]()
[![License](https://img.shields.io/badge/Framework-container-blue)]()
[![License](https://img.shields.io/badge/NextJS-2.4.0-yellow)]()
[![License](https://img.shields.io/badge/Tribe-productivity_platform-lightblue)]()
[![License](https://img.shields.io/badge/Squad-platform_services-lightblue)]() 
[![CI](https://github.com/rewards-devops/rr-lunchnlearn-web/actions/workflows/ci.yaml/badge.svg)](https://github.com/rewards-devops/rr-lunchnlearn-web/actions/workflows/ci.yaml)
[![CD](https://github.com/rewards-devops/rr-lunchnlearn-web/actions/workflows/cd.yaml/badge.svg)](https://github.com/rewards-devops/rr-lunchnlearn-web/actions/workflows/cd.yaml)

# rr-lunchnlearn-web

Created with [Rakuten Rewards Next](https://github.com/rewards-foundation/rakuten-rewards-next)! 🔥

## Setup

### Nexus Private Registry

We are using a private NPM registry for `@rakuten-rewards` modules. Make sure you have access to our internal NPM registry.

Please follow the setup [here](https://rakutenrewards.atlassian.net/wiki/spaces/GUILDS/pages/19503940115/Using+the+Nexus+Private+Registry#UsingtheNexusPrivateRegistry-Setup) by running the `npm config` command outlined, in order to be to proceed with **Installation** down below.

### Installation

```
yarn
```

### Usage

#### `yarn dev`

Runs the app in development mode.

Open <http://localhost:3000> to view it in the browser.

The page will automatically reload if you make changes to the code.

You will see the build errors and lint warnings in the console.

#### `yarn build`

Builds the app for production to the build folder.

It correctly bundles React in production mode and optimizes the build for the best performance.

#### `yarn lint`

Runs ESLint and Stylelint on your files.

#### `yarn test`

Runs the test watcher in an interactive mode.

By default, runs tests related to files changed since the last commit.

## Create and run a docker image locally

```bash
docker-compose up
```

Then go to `http://localhost:3000` in your browser. Since the volume is mounted, the development experience is almost the same.

## Development and Recipes

Look [here](https://rakutenrewards.atlassian.net/wiki/spaces/GUILDS/pages/19586353196/Radiant+React+Web+Development+Playbook+and+Guide) to find documentation and links to implementation and development recipes, as well as expanded details and explanations on specific releases.

## Adding Radiant Modules

You'll most likely want to integrate the AppShell and RRFeed to render a consistent Radiant UX experience with the Feed.

Look [here](https://rakutenrewards.atlassian.net/wiki/spaces/GUILDS/pages/19586353196/Radiant+React+Web+Development+Playbook+and+Guide#Using-Radiant-Web-Modules) on what to do to get started.

## CD
* [CD-v3 Onboarding-Guide](https://rakutenrewards.atlassian.net/wiki/spaces/PDO/pages/43699994989/GHA+v3.0.x+Usage+Playbook)
