const babelConfig = require('@rakuten-rewards/next-dev-tools/babel.config');

module.exports = babelConfig;
